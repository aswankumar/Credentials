
public class User {
	String firstname,lastname,username,password,gender,language;
	public void setFirstName(String firstname)
	{
		this.firstname=firstname;
	}
	public String getFirstName()
	{
		return firstname;
	}
	public void setLastName(String lastname)
	{
		this.lastname=lastname;
	}
	public String getLastName()
	{
		return lastname;
	}
	public void setUserName(String username)
	{
		this.username=username;
	}
	public String getUserName()
	{
		return username;
	}
	public void setPassWord(String password)
	{
		this.password=password;
	}
	public String getPassWord()
	{
		return password;
	}
	public void setGender(String gender)
	{
		this.gender=gender;
	}
	public String getGender()
	{
		return gender;
	}
	public void setLanguage(String language)
	{
		this.language=language;
	}
	public String getLanguage()
	{
		return language;
	}

}
