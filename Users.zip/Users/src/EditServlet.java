

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public EditServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<b>Update Profile</b>");
		String un=request.getParameter("username");
		String pd=request.getParameter("pswd");
		User a=UserDao.verify(un, pd);
		pw.print("<form action='EditServlet2' method='post'");
		pw.print("<table>");
		pw.print("<tr><td>First Name :</td><td<input type='text' name='firstname' value='"+a.getFirstName()+"'/></td></tr>");
		pw.print("<tr><td>Last Name :</td><td<input type='text' name='lastname' vlaue='"+a.getLastName()+"'/></td></tr>");
		pw.print("<tr><td>User Name :</td><td<input type='text' name='username' value='"+a.getUserName()+"'/></td></tr>");
		pw.print("<tr><td>Last Name :</td><td<input type='password' name='pswd' vlaue='"+a.getPassWord()+"'/></td></tr>");
		pw.print("<tr><td></td><td<input type='radio' name='gender' value='male'>Male<input type='radio' name='gender' value='female'>Female<br>/></td></tr>");
		pw.print("<tr><td>Check the languages you know</td><td <input type='checkbox' name='language' value='Hindi'>HINDI<br><input type='checkbox' name='language' value='English'>English<br><input type='checkbox' name='language' value='Telugu'>Telugu<br>/></td></tr>");
		pw.print("<tr><td colspan='2'><input type='submit' value='Edit & Save'/></td></tr>");
		pw.print("</table>");
		pw.print("</form>");
		pw.close();
	}

}
