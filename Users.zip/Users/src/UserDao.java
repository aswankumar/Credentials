
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
	
	public static Connection getConnection()
	{
		Connection con=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/databasename","root","root");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	
	public static int save(User u)
	{
		int status=0;
		try
		{
			Connection con=UserDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into users values(?,?,?,?,?,?)");
			ps.setString(1, u.getFirstName());
			ps.setString(2, u.getLastName());
			ps.setString(3, u.getUserName());
			ps.setString(4, u.getPassWord());
			ps.setString(5, u.getGender());
			ps.setString(6, u.getLanguage());
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
	
	public static User verify(String un,String pd)
	{
		User a=new User();
		try
		{
			Connection con=UserDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from users where username=?");
			ps.setString(1, un);
			ResultSet rs=ps.executeQuery();
			if (rs.next())
			{
				if(rs.getString(4).equals(pd))
				{
					a.setFirstName(rs.getString(1));
					a.setLastName(rs.getString(2));
					a.setUserName(rs.getString(3));
					a.setPassWord(rs.getString(4));
					a.setGender(rs.getString(5));
					a.setLanguage(rs.getString(6));
					
				}
				con.close();
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return a;
	}
	
	public static int update (User u)
	{
		int status=0;
		try
		{
			Connection con=UserDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update users set firstname=?,lastname=?,password=?,gender=?,language=? where username=?");
			ps.setString(1, u.getFirstName());
			ps.setString(2, u.getLastName());
			ps.setString(3, u.getPassWord());
			ps.setString(4, u.getGender());
			ps.setString(5, u.getLanguage());
			ps.setString(6, u.getUserName());
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return status;
	}
	public static int delete(String un)
	{
		int status=0;
		try
		{
			Connection con=UserDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from users where username=?");
			ps.setString(1, un);
			status=ps.executeUpdate();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
}
