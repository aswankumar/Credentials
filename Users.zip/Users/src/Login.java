

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Login() {
        super();
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String un=request.getParameter("username");
		String pd=request.getParameter("pswd");
		
		User a=UserDao.verify(un,pd);
		pw.println("First Name :"+a.getFirstName());
		pw.println("Last Name :"+a.getLastName());
		pw.println("User Name :"+ a.getUserName());
		pw.println("Gender :"+a.getGender());
		pw.println("Languages :"+a.getLanguage());
		pw.println("<a href='EditServlet?username="+a.getUserName()+"&pswd="+a.getPassWord()+"'>edit</a>");
		pw.println("<a href='DeleteServlet?username="+a.getUserName()+"'>delete</a>");
	}

}
