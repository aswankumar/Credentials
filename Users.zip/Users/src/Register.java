

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public Register() {
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String fn=request.getParameter("firstname");
		String ln=request.getParameter("lastname");
		String un=request.getParameter("username");
		String pd=request.getParameter("pswd");
		String g=request.getParameter("gender");
		String l=request.getParameter("language");
		
		User u=new User();
		u.setFirstName(fn);
		u.setLastName(ln);
		u.setUserName(un);
		u.setPassWord(pd);
		u.setGender(g);
		u.setLanguage(l);
		
		int status=UserDao.save(u);
		if(status>0)
		{
			pw.print("<p>Registration successfull</p>");
			request.getRequestDispatcher("login.html").include(request, response);
		}
		else
		{
			pw.print("Sorry! Unable to register");
		}
		pw.close();
		
	}

}
